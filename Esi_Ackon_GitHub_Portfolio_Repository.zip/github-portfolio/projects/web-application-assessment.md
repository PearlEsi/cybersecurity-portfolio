# Web Application Vulnerability Assessment

## Overview
Practical security testing in controlled training environments, including OWASP Juice Shop and Electron Store.

## Tools and focus
- Burp Suite for request and response inspection.
- Nmap and Nikto for reconnaissance and service/web-server checks.
- Assessment themes included sensitive data exposure, broken access control and improper input validation.

## Output
Documented security observations and remediation themes, with attention to impact and secure application behaviour.

## Skills
Web application testing, OWASP awareness, vulnerability analysis and remediation communication.

## Safety
Testing was limited to intentionally vulnerable training applications or explicitly authorised targets.
