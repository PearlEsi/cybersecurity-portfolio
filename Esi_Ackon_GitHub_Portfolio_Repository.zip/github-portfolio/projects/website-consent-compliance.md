# Website Tracking Consent and Privacy Compliance

## Overview
MSc Cyber Security research examining website tracking consent against GDPR and Data Protection Act 2018 requirements.

## Method
- Sample: 100 websites, divided into reject-all and accept-all consent journeys.
- Environment: Linux virtual machine in VirtualBox; Firefox, Chrome and Edge.
- Tools: Wireshark, Privacy Badger and uBlock Origin.
- Observations: cookie behaviour, third-party requests, consent persistence, HTTPS/QUIC traffic and consent-interface patterns.

## Outcome
The study reported 79% compliance within its assessment framework. Findings highlighted the importance of meaningful user choice, persistent consent preferences and transparent third-party tracking.

## Skills
Privacy assessment, browser testing, network traffic analysis, GDPR, evidence collection and technical reporting.

## Evidence to add
Add a sanitised methodology diagram, anonymised results table or screenshots only if they contain no personal data and can be shared.
