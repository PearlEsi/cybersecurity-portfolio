# Service Reporting and Process Improvement

## Overview
Data and compliance reporting work at Rhythex Consulting using SQL and ACL scripting.

## Contribution
- Supported SLA and KPI analysis and reporting.
- Applied automation to reduce manual reporting effort by approximately 40%.
- Helped improve consistency and usability of operational information.

## Skills
SQL, ACL, data analysis, audit support, reporting and process improvement.

## Evidence to add
Add a synthetic dataset and a recreated example workflow. Do not publish company data, client information or proprietary scripts.
