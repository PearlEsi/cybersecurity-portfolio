# Security Monitoring and Threat Investigation

## Overview
Cybersecurity internship exercises involving threat intelligence, cloud monitoring and SIEM investigation.

## Work completed
- Explored APT39 threat intelligence.
- Used VirusTotal and Any.Run for analysis of suspicious artefacts.
- Reviewed Azure Monitor, Log Analytics and Microsoft Sentinel telemetry.
- Used KQL to query and investigate log data.
- Considered least-privilege access requirements, including Log Reader permissions.
- Reviewed security awareness and phishing simulation outputs in Wizer.

## Skills
SIEM, KQL, threat intelligence, cloud monitoring, log analysis and security awareness.

## Evidence to add
Include only sanitised sample KQL queries, synthetic logs and diagrams. Never publish real tenant identifiers, IP addresses, tokens, customer data or employer telemetry.
